package com.helloxiaopeng.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.helloxiaopeng.mapper.UserMapper;
import com.helloxiaopeng.pojo.User;
import com.helloxiaopeng.pojo.UserExample;
import com.helloxiaopeng.pojo.UserExample.Criteria;
import com.helloxiaopeng.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserMapper userMapper;

	@Override
	public User getUserByName(String name) {
		UserExample example = new UserExample();
		Criteria criteria = example.createCriteria();
		criteria.andUsernameEqualTo(name);
		System.out.println(example);
		System.out.println(userMapper);
		List<User> list = userMapper.selectByExample(example);
		if (list != null && list.size() > 0) {
			return list.get(0);
		}
		return null;
	}

}

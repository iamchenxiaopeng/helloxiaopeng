package com.helloxiaopeng.service;

import com.helloxiaopeng.pojo.User;

public interface UserService {
	User getUserByName(String name);
}
